Credits to Brice Huang and Brian Gu for their work on a script which
automatically verifies the transcript.

As of 5 December 2019, the Semaphore team has verified all challenge and
response files up to #15.

https://github.com/bricehuang/powersoftau-verifier
